# 🏦 Macro Trading Bot — Guide d'installation complet

Bot Telegram d'analyse macro institutionnelle avec 40+ fonctions.
Hébergement H24 sur Railway.app (gratuit).

---

## ÉTAPE 1 — Créer le bot Telegram avec BotFather

1. Ouvre Telegram et cherche **@BotFather**
2. Tape `/newbot`
3. Donne un nom au bot : ex. `Macro Trading Analyst`
4. Donne un username (doit finir en "bot") : ex. `macro_analyst_bot`
5. BotFather te donne un **token** → **COPIE-LE**, tu en auras besoin

---

## ÉTAPE 2 — Récupérer ton CHAT_ID

1. Cherche **@userinfobot** dans Telegram
2. Envoie `/start`
3. Il te donne ton **ID numérique** → **COPIE-LE**

---

## ÉTAPE 3 — Obtenir une clé API Anthropic

1. Va sur **https://console.anthropic.com**
2. Crée un compte si tu n'en as pas
3. Va dans **API Keys** → **Create Key**
4. **COPIE la clé** (commence par `sk-ant-...`)

---

## ÉTAPE 4 — Créer un compte GitHub et uploader le code

1. Va sur **https://github.com** et crée un compte
2. Clique **New repository** → Nomme-le `macro-trading-bot`
3. Laisse-le **Public** ou **Private** (les deux marchent)
4. Clique **Create repository**
5. Sur la page du repo, clique **uploading an existing file**
6. Upload ces 4 fichiers :
   - `bot.py`
   - `requirements.txt`
   - `Procfile`
   - `railway.toml`
7. Clique **Commit changes**

---

## ÉTAPE 5 — Déployer sur Railway.app

1. Va sur **https://railway.app**
2. Clique **Start a New Project**
3. Sélectionne **Deploy from GitHub repo**
4. Autorise Railway à accéder à GitHub
5. Sélectionne ton repo `macro-trading-bot`
6. Railway détecte automatiquement le code Python

---

## ÉTAPE 6 — Configurer les variables d'environnement

Dans Railway, clique sur ton projet → onglet **Variables** → ajoute ces 4 variables :

| Nom | Valeur |
|-----|--------|
| `TELEGRAM_TOKEN` | Le token BotFather (ex: `7123456789:AAF...`) |
| `ANTHROPIC_API_KEY` | Ta clé Anthropic (ex: `sk-ant-api03-...`) |
| `CHAT_ID` | Ton ID Telegram (ex: `123456789`) |
| `TIMEZONE` | `Europe/Paris` (ou ta timezone) |

---

## ÉTAPE 7 — Démarrer le bot

1. Dans Railway, clique **Deploy** (ou il démarre automatiquement)
2. Attends 1-2 minutes que le déploiement se termine
3. Ouvre Telegram → cherche ton bot par son username
4. Tape `/start`
5. ✅ Ton bot est en ligne H24 !

---

## TOUTES LES COMMANDES

### Modules terminal
| Commande | Description |
|----------|-------------|
| `/menu` | Interface avec tous les boutons cliquables |
| `/bilan` | Bilan N-1 + Arc de tendance |
| `/calendrier` | Calendrier éco semaine filtré |
| `/macro` | Macro & Politiques monétaires Fed/BCE/BoJ/PBoC |
| `/geopolitique` | Géopolitique & Flux mondiaux |
| `/xauusd` | Analyse complète XAU/USD |
| `/eurusd` | Analyse complète EUR/USD |
| `/dxy` | Analyse DXY + corrélations |
| `/btc` | Analyse BTC/ETH |
| `/sp500` | Analyse S&P 500 |
| `/petrole` | Analyse Pétrole WTI/Brent |
| `/projections` | Projections bancaires GS/JPM/BNP/ING |
| `/cot` | COT + Sentiment + Flux |
| `/timing` | Timing d'entrée Pré/Pendant/Post-news |
| `/synthese` | Synthèse & Stratégie finale |
| `/classement` | Classement des 5 actifs à trader |
| `/analyse_hebdo` | Analyse hebdo complète (tous modules) |

### Nouvelles fonctions
| Commande | Description |
|----------|-------------|
| `/analyse [actif]` | Analyse libre (NVIDIA, argent, CAC40, etc.) |
| `/consensus [actif]` | Consensus banques sur un actif |
| `/briefing` | Briefing macro du jour à la demande |
| `/bilan_jour` | Bilan chiffres de la journée + deltas |
| `/calendrier_mois` | Calendrier du mois filtré actifs tradés |
| `/analyse_mensuelle` | Analyse mensuelle complète |

### Alertes automatiques (sans rien faire)
| Heure | Alerte |
|-------|--------|
| 07h00 | ☀️ Briefing du jour automatique |
| 22h00 | 🌙 Bilan du jour automatique |
| 1er du mois 08h00 | 📅 Analyse mensuelle automatique |

---

## ACTIFS FILTRÉS DANS LE CALENDRIER

Seules les annonces impactant ces actifs sont incluses :
**XAU/USD · DXY · EUR/USD · S&P 500 · BTC/ETH · Pétrole WTI/Brent**

Annonces incluses : CPI, NFP, PCE, FOMC, PIB US, ISM, Jobless Claims,
JOLTS, Ventes détail, ADP, Michigan Sentiment, BCE, CPI Zone Euro,
PIB Zone Euro, Discours Fed/BCE, EIA Stocks, OPEP.

---

## DÉPANNAGE

**Le bot ne répond pas :**
- Vérifie que les variables d'environnement sont bien renseignées dans Railway
- Va dans Railway → Logs pour voir les erreurs

**Erreur "Unauthorized" :**
- Le TELEGRAM_TOKEN est incorrect, revérifie avec BotFather

**Erreur API Anthropic :**
- Vérifie ton crédit sur console.anthropic.com
- La clé API est peut-être expirée

**Redéployer après une modification :**
- Upload les nouveaux fichiers sur GitHub
- Railway redéploie automatiquement

---

## COÛT ESTIMÉ

| Service | Coût |
|---------|------|
| Railway.app | Gratuit (500h/mois) ou ~5$/mois Pro |
| Anthropic API | ~0.015$ par analyse · ~5-15$/mois selon usage |
| Telegram BotFather | Gratuit |

---

*Bot créé avec Claude (Anthropic) · Framework Macro Trading Institutionnel*
